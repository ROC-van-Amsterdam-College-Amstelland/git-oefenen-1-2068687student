var mijnEersteVariabele;
mijnEersteVariabele = false;
