function bereken() {
    var getal1 = document.getElementById("getal1").innerHTML
    var getal2 = document.getElementById("getal2").innerHTML
    document.getElementById("output").innerHTML = getal1 * getal2;
}