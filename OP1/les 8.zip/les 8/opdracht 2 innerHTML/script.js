function toonTekst() {
    var voornaam ="adjani";
    var achternaam = 'Valerius';

    document.getElementById("tekst").innerHTML = voornaam + " " + achternaam;
    document.getElementById("tekst").style.fontSize = "20px";
    
       
}

