
//Maak twee variabelen - volgorde van uitlezen door browser
// Toon variabelen op het scherm
// Vraag gebruiker om een INPUT waarde
// Toon de gevraagde waarde in een DIV en in een INPUT FIELD


// var getal1 = 23;
// document.getElementById("main").innerHTML = getal1;  //getal2 kan ik nog niet gebruiken

// var getal2 = 75;

// document.getElementById("main").innerHTML = getal2;

// var doos_met_een_getal = prompt("geef een getal"); //
// var nog_een_doos_met_getal = prompt("Geef nog een getal");

// document.getElementById("main").innerHTML = doos_met_een_getal;