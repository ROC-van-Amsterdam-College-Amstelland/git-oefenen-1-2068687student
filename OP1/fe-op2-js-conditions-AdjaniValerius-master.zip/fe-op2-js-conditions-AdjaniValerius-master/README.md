# FE-Opdr-Conditions
## Frontend Essentials Opdracht Javascript Conditions

Maak eerst opdracht 1 en opdracht 2

### Opdracht 1
 * A) maak 2 verschillende variabelen met twee willekeurige integers (zelf kiezen)
 * B) toon beide getallen op het scherm met document.getElementById('<jouw_gekozen_id>').innerHTML
 * C) Vraag de gebruiker om een INPUT waarde door prompt() te gebruiken
 * D) Vergelijk de twee getallen met elkaar door gebruikte maken van conditions  if() 
 
 ### Opdracht 2 
 * A) Schrijf code waarmee je ingevulde waarde uit het invulveld 'ophaalt'
 * B) Schrijf code waarmee je het ingevulde getal vergelijkt (condition) met de stemgerechtigde leeftijd van 18 jaar. Als de       leeftijd kleiner is dan 18...
 * C) Schrijf code waarmee je het ingevulde getal vergelijkt (condition) met de stemgerechtigde leeftijd van 18 jaar. leeftijd groter is dan 18...

## Huiswerk

### Opdracht 1
Maak de opdracht uit de PowerPoint
### Opdracht 2
Maak de opdracht uit de map. Lees goed


### Links
[Javascript Conditions](https://www.tutorialsteacher.com/javascript/javascript-if-else-condition)
